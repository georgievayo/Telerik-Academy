﻿namespace Academy.Models
{
    public enum Track
    {
        Frontend,
        Dev,
        None
    }
}