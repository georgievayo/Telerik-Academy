﻿namespace Academy.Models.Enums
{
    public enum Grade
    {
        Excellent,
        Passed,
        Failed
    }
}
